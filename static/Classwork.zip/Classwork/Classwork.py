import pygame
import os, os.path
import random
import math

# инициализация pygame:
pygame.init()
# размеры окна: 
size = width, height = 500, 500
# screen — холст, на котором нужно рисовать:
screen = pygame.display.set_mode(size)

def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
    image.set_colorkey(colorkey)
    return image


# создадим группу, содержащую все спрайты
all_sprites = pygame.sprite.Group()

running = True
fps = 50
clock = pygame.time.Clock()
screen.fill(pygame.Color('white'))


horizontal_borders = pygame.sprite.Group()
vertical_borders = pygame.sprite.Group()


class Bomb(pygame.sprite.Sprite):
    image = load_image("bomb2.png")
 
    def __init__(self, group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(group)
        self.image = Bomb.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, 450)
        self.rect.y = random.randint(0, 449)
 
    def update(self):
        k1 = random.randrange(3)
        k2 = random.randrange(3)
        self.rect = self.rect.move(k1 - 1,
                                   k2 - 1)
        while self.watch():
            self.rect = self.rect.move(-k1 + 1,
                                       -k2 + 1)
            k1 = random.randrange(3)
            k2 = random.randrange(3)
            self.rect = self.rect.move(k1 - 1,
                                       k2 - 1)
    def changed(self):
        image = load_image('boom.png')
        self.image = image

    def watch(self):
        for s1 in all_sprites:
            if pygame.sprite.collide_rect(self, s1) and s1 != self:
                return True
        return False

    
class Border(pygame.sprite.Sprite):
    # строго вертикальный или строго горизонтальный отрезок
    def __init__(self, x1, y1, x2, y2):
        super().__init__(horizontal_borders)
        if x1 == x2:  # вертикальная стенка
            self.add(vertical_borders)
            self.image = pygame.Surface([1, y2 - y1])
            self.rect = pygame.Rect(x1, y1, 1, y2 - y1)
        else:  # горизонтальная стенка
            self.add(horizontal_borders)
            self.image = pygame.Surface([x2 - x1, 1])
            self.rect = pygame.Rect(x1, y1, x2 - x1, 1)

Border(5, 5, width - 5, 5)
Border(5, height - 5, width - 5, height - 5)
Border(5, 5, 5, height - 5)
Border(width - 5, 5, width - 5, height - 5)


for _ in range(5):
    Bomb(all_sprites)
    
# в главном игровом цикле
all_sprites.draw(screen)
all_sprites.update()

while running:
    screen.fill(pygame.Color('white'))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            for el in all_sprites:
                if event.pos[0] in range(el.rect.x, el.rect.x + 100) and event.pos[1] in range(el.rect.y, el.rect.y + 100):
                    el.changed()
    all_sprites.draw(screen)
    all_sprites.update()
    clock.tick(fps)
    pygame.display.flip()

# завершение работы:
pygame.quit()

